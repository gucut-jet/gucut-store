// ข้อมูลสินค้า snapshot จากร้าน Shopify จริงของ GUCUT (ดึงเมื่อ ก.ค. 2026)
// ชื่อ / ราคา / รูป / variant / คำอธิบาย = ของจริง | ยอดขาย (sold) และราคาก่อนลด (compareAtPrice) = ตัวเลขตัวอย่างสำหรับ demo
// Phase 2 จะสลับไปดึงสดจาก Storefront API ผ่าน lib/shopify.ts

export type Category = "chainsaw" | "chain" | "accessory";

export interface Variant {
  title: string;
  price: number;
  stock: number;
}

export interface Product {
  id: string; // Shopify GID จริง
  handle: string;
  title: string;
  price: number; // ราคาเริ่มต้น (บาท)
  compareAtPrice?: number; // ราคาก่อนลด (demo)
  image: string; // รูปหลัก (ใช้ในการ์ด)
  images: string[]; // รูปทั้งหมด (สไลด์ในหน้าสินค้า)
  sold: number; // demo
  category: Category;
  flashSale?: boolean;
  description?: string; // คำอธิบายจริงจาก Shopify (คั่นด้วย •)
  variants?: Variant[]; // ตัวเลือกรุ่น/ขนาดจริง
  youtubeId?: string; // วิดีโอรีวิว YouTube (ใส่ id จริงภายหลัง)
}

const CDN = "https://cdn.shopify.com/s/files/1/0905/1081/9620/files";

export const products: Product[] = [
  {
    id: "gid://shopify/Product/9888885965092",
    handle: "เลื่อยยนต์-kingkong",
    title: "เลื่อยยนต์ KingKong 5800 รุ่นใหม่ปี 2025 (เฉพาะเครื่อง)",
    price: 4500,
    compareAtPrice: 5200,
    image: `${CDN}/kingkong-5800-2025-825467.webp?v=1750863081`,
    images: [
      `${CDN}/kingkong-5800-2025-825467.webp?v=1750863081`,
      `${CDN}/kingkong-5800-2025-774677.webp?v=1750863082`,
      `${CDN}/kingkong-5800-2025-561291.webp?v=1750863083`,
      `${CDN}/kingkong-5800-2025-797997.webp?v=1750863085`,
      `${CDN}/kingkong-5800-2025-869765.webp?v=1750863086`,
    ],
    sold: 872,
    category: "chainsaw",
    flashSale: true,
    description:
      "เลื่อยยนต์ King Kong 5800 ทรงพลัง คล่องตัว ตอบโจทย์ทุกงานตัด • เครื่องยนต์ทรงพลัง : ขุมพลังที่ออกแบบมาเพื่อการตัดที่รวดเร็วและแม่นยำ • ดีไซน์แข็งแกร่ง: โครงสร้างทนทาน ใช้งานได้ยาวนานในทุกสภาพแวดล้อม • น้ำหนักเบา: ใช้งานง่าย คล่องตัว จับถนัดมือ แม้ต้องทำงานนาน • ระบบสตาร์ทง่าย (Easy Start): พร้อมใช้งานทันที สะดวกในทุกสถานการณ์ • ระบบลดแรงสั่นสะเทือน: ช่วยลดความเมื่อยล้าระหว่างใช้งาน • ใบเลื่อยคุณภาพสูง: ตัดได้ทั้งไม้เนื้ออ่อน ไม้เนื้อแข็ง และไม้ขนาดกลาง • ประหยัดพลังงาน: ลดการสิ้นเปลืองเชื้อเพลิง แต่ยังคงประสิทธิภาพสูงสุด • ถังน้ำมันขนาดพอเหมาะ: รองรับการใช้งานต่อเนื่อง ไม่ต้องเติมน้ำมันบ่อย",
    variants: [{ title: "เฉพาะเครื่อง", price: 4500, stock: 21 }],
  },
  {
    id: "gid://shopify/Product/9888888586532",
    handle: "เลื่อยยนต์-newwave-7800-super-s",
    title: "เลื่อยยนต์ NEWWAVE 7800 SUPER-S",
    price: 6000,
    compareAtPrice: 6900,
    image: `${CDN}/newwave-7800-super-s-594397.webp?v=1750863107`,
    images: [
      `${CDN}/newwave-7800-super-s-594397.webp?v=1750863107`,
      `${CDN}/newwave-7800-super-s-782140.webp?v=1750863108`,
      `${CDN}/newwave-7800-super-s-704049.webp?v=1750863109`,
      `${CDN}/newwave-7800-super-s-273140.webp?v=1750863111`,
      `${CDN}/newwave-7800-super-s-669435.webp?v=1750863113`,
    ],
    sold: 1204,
    category: "chainsaw",
    flashSale: true,
    description:
      "เลื่อยยนต์ NEWWAVE 7800 SUPER S สุดยอดพลังการตัด ตอบโจทย์งานหนักทุกประเภท • เครื่องยนต์ทรงพลัง : รองรับการตัดไม้ขนาดใหญ่ได้อย่างง่ายดาย รวดเร็ว และมีประสิทธิภาพ • ระบบ SUPER S: เทคโนโลยีใหม่ เพิ่มแรงม้า ลดการสึกหรอ ใช้งานได้ต่อเนื่องโดยไม่สะดุด • ใบเลื่อยคุณภาพสูง: ตัดได้ทั้งไม้เนื้ออ่อนและเนื้อแข็ง มาพร้อมความคมกริบที่ทนทาน • โครงสร้างแข็งแรง: วัสดุเกรดพรีเมียม น้ำหนักเบา แต่ทนต่อการใช้งานหนัก • ระบบสตาร์ทง่าย (Easy Start): เริ่มใช้งานได้ทันที แม้ในสภาพอากาศเย็น • ประหยัดเชื้อเพลิง: ออกแบบให้ใช้พลังงานอย่างมีประสิทธิภาพ คุ้มค่าในระยะยาว • ระบบลดแรงสั่นสะเทือน (Anti-Vibration): ใช้งานได้อย่างสบาย ลดความเมื่อยล้าระหว่างการทำงาน • ถังน้ำมันขนาดใหญ่: เพิ่มระยะเวลาใช้งาน ไม่ต้องเติมเชื้อเพลิงบ่อย",
    variants: [
      { title: "เฉพาะตัวเครื่อง", price: 6000, stock: 0 },
      { title: '11.8"', price: 7300, stock: 0 },
    ],
  },
  {
    id: "gid://shopify/Product/9888888422692",
    handle: "เลื่อยยนต์-newwave-7800-turbo",
    title: "เลื่อยยนต์ NEWWAVE 7800 TURBO",
    price: 6500,
    image: `${CDN}/newwave-7800-turbo-598224.webp?v=1750863093`,
    images: [
      `${CDN}/newwave-7800-turbo-598224.webp?v=1750863093`,
      `${CDN}/newwave-7800-turbo-814187.webp?v=1750863094`,
      `${CDN}/newwave-7800-turbo-575158.webp?v=1750863095`,
      `${CDN}/newwave-7800-turbo-576158.webp?v=1750863097`,
      `${CDN}/newwave-7800-turbo-454255.webp?v=1750863098`,
    ],
    sold: 655,
    category: "chainsaw",
    description:
      "เลื่อยยนต์ NEWWAVE 7800 TURBO พลังแรง ตัดไว ทนทานทุกงาน • เครื่องยนต์ทรงพลัง : รองรับงานหนัก ตัดไม้ได้อย่างรวดเร็วและมีประสิทธิภาพ • เทคโนโลยี TURBO: เพิ่มแรงตัด ลดการสิ้นเปลืองเชื้อเพลิง และเพิ่มความคมชัดในการตัด • โครงสร้างแข็งแรง: ผลิตจากวัสดุเกรดพรีเมียม ใช้งานได้นาน ทนต่อสภาพการใช้งานสมบุกสมบัน • ระบบสตาร์ทง่าย: พร้อมใช้งานในทุกสถานการณ์ด้วยระบบ Easy Start • น้ำหนักสมดุล: จับถนัดมือ ใช้งานง่าย แม้ในพื้นที่แคบ • ระบบลดแรงสั่นสะเทือน: ช่วยลดความเมื่อยล้าระหว่างการใช้งาน • ใบเลื่อยคมกริบ: ตัดได้ทั้งไม้เนื้ออ่อนและเนื้อแข็ง",
    variants: [{ title: "มาตรฐาน", price: 6500, stock: 0 }],
  },
  {
    id: "gid://shopify/Product/9888894320932",
    handle: "เลื่อยยนต์-newwave-f250-มีเอกสารพร้อมขึ้นทะเบียน",
    title: "เลื่อยยนต์ NEWWAVE F250 (มีทะเบียน)",
    price: 9000,
    image: `${CDN}/newwave-f250-954401.webp?v=1750863148`,
    images: [
      `${CDN}/newwave-f250-954401.webp?v=1750863148`,
      `${CDN}/newwave-f250-147055.webp?v=1750863149`,
      `${CDN}/newwave-f250-280967.webp?v=1750863151`,
      `${CDN}/newwave-f250-393130.webp?v=1750863152`,
      `${CDN}/newwave-f250-433182.webp?v=1750863153`,
    ],
    sold: 318,
    category: "chainsaw",
    description:
      "มีเอกสารพร้อมขึ้นทะเบียน (คำขอรับใบอนุญาต ลซ.1) • วิธีขอใบอนุญาตเลื่อยโซ่ยนต์: ดาวน์โหลดเอกสาร ลซ.1 • เตรียมสำเนาบัตรประชาชน + ทะเบียนบ้าน อย่างละ 4 ชุด และใบรับรองแพทย์ • ยื่นที่สำนักงานทรัพยากรธรรมชาติและสิ่งแวดล้อมจังหวัดของท่าน",
    variants: [{ title: "มาตรฐาน", price: 9000, stock: 3 }],
  },
  {
    id: "gid://shopify/Product/9888894976292",
    handle: "เลื่อยยนต์-newwave-f381-มีเอกสารพร้อมขึ้นทะเบียน",
    title: "เลื่อยยนต์ NEWWAVE F381 (มีทะเบียน)",
    price: 14000,
    image: `${CDN}/newwave-f381-1446266.jpg?v=1755678147`,
    images: [
      `${CDN}/newwave-f381-1446266.jpg?v=1755678147`,
      `${CDN}/newwave-f381-364411.webp?v=1755571472`,
      `${CDN}/newwave-f381-231719.webp?v=1755571472`,
      `${CDN}/newwave-f381-157760.webp?v=1755571472`,
      `${CDN}/newwave-f381-843753.webp?v=1755571472`,
    ],
    sold: 190,
    category: "chainsaw",
    description:
      "มีเอกสารพร้อมขึ้นทะเบียน (คำขอรับใบอนุญาต ลซ.1) • วิธีขอใบอนุญาตเลื่อยโซ่ยนต์: ดาวน์โหลดเอกสาร ลซ.1 • เตรียมสำเนาบัตรประชาชน + ทะเบียนบ้าน อย่างละ 4 ชุด และใบรับรองแพทย์ • ยื่นที่สำนักงานทรัพยากรธรรมชาติและสิ่งแวดล้อมจังหวัดของท่าน",
    variants: [{ title: "มาตรฐาน", price: 14000, stock: 0 }],
  },
  {
    id: "gid://shopify/Product/9888895566116",
    handle: "เลื่อยยนต์-newwave-f440-มีเอกสารพร้อมขึ้นทะเบียน",
    title: "เลื่อยยนต์ NEWWAVE F440 (มีทะเบียน)",
    price: 15000,
    image: `${CDN}/newwave-f440-154843.webp?v=1750863200`,
    images: [
      `${CDN}/newwave-f440-154843.webp?v=1750863200`,
      `${CDN}/newwave-f440-555191.webp?v=1750863201`,
      `${CDN}/newwave-f440-807741.webp?v=1750863203`,
      `${CDN}/newwave-f440-125518.webp?v=1750863204`,
      `${CDN}/newwave-f440-822041.webp?v=1750863205`,
    ],
    sold: 226,
    category: "chainsaw",
    description:
      "มีเอกสารพร้อมขึ้นทะเบียน (คำขอรับใบอนุญาต ลซ.1) • วิธีขอใบอนุญาตเลื่อยโซ่ยนต์: ดาวน์โหลดเอกสาร ลซ.1 • เตรียมสำเนาบัตรประชาชน + ทะเบียนบ้าน อย่างละ 4 ชุด และใบรับรองแพทย์ • ยื่นที่สำนักงานทรัพยากรธรรมชาติและสิ่งแวดล้อมจังหวัดของท่าน",
    variants: [{ title: "มาตรฐาน", price: 15000, stock: 0 }],
  },
  {
    id: "gid://shopify/Product/9888896090404",
    handle: "เลื่อยยนต์-newwave-f288xp-มีเอกสารพร้อมขึ้นทะเบียน",
    title: "เลื่อยยนต์ NEWWAVE F288XP (มีทะเบียน)",
    price: 15000,
    image: `${CDN}/newwave-f288xp-410999.webp?v=1750863208`,
    images: [
      `${CDN}/newwave-f288xp-410999.webp?v=1750863208`,
      `${CDN}/newwave-f288xp-584415.webp?v=1750863209`,
      `${CDN}/newwave-f288xp-632077.webp?v=1750863211`,
      `${CDN}/newwave-f288xp-865304.webp?v=1750863212`,
      `${CDN}/newwave-f288xp-238754.webp?v=1750863213`,
    ],
    sold: 164,
    category: "chainsaw",
    description:
      "มีเอกสารพร้อมขึ้นทะเบียน (คำขอรับใบอนุญาต ลซ.1) • วิธีขอใบอนุญาตเลื่อยโซ่ยนต์: ดาวน์โหลดเอกสาร ลซ.1 • เตรียมสำเนาบัตรประชาชน + ทะเบียนบ้าน อย่างละ 4 ชุด และใบรับรองแพทย์ • ยื่นที่สำนักงานทรัพยากรธรรมชาติและสิ่งแวดล้อมจังหวัดของท่าน",
    variants: [{ title: "มาตรฐาน", price: 15000, stock: 0 }],
  },
  {
    id: "gid://shopify/Product/9888888848676",
    handle: "เลื่อยยนต์-newwave-8800-super-s-28-มีเอกสารพร้อมขึ้นทะเบียน",
    title: "เลื่อยยนต์ NEWWAVE 8800 SUPER-S 28″ (มีทะเบียน)",
    price: 20000,
    image: `${CDN}/newwave-8800-super-s-28-196563.jpg?v=1750863122`,
    images: [
      `${CDN}/newwave-8800-super-s-28-196563.jpg?v=1750863122`,
      `${CDN}/newwave-8800-super-s-28-561617.jpg?v=1750863124`,
      `${CDN}/newwave-8800-super-s-28-130010.jpg?v=1750863126`,
      `${CDN}/newwave-8800-super-s-28-248227.jpg?v=1750863127`,
      `${CDN}/newwave-8800-super-s-28-718501.jpg?v=1750863129`,
    ],
    sold: 87,
    category: "chainsaw",
    description:
      "มีเอกสารพร้อมขึ้นทะเบียน (คำขอรับใบอนุญาต ลซ.1) • วิธีขอใบอนุญาตเลื่อยโซ่ยนต์: ดาวน์โหลดเอกสาร ลซ.1 • เตรียมสำเนาบัตรประชาชน + ทะเบียนบ้าน อย่างละ 4 ชุด และใบรับรองแพทย์ • ยื่นที่สำนักงานทรัพยากรธรรมชาติและสิ่งแวดล้อมจังหวัดของท่าน",
    variants: [{ title: '28"', price: 20000, stock: 9 }],
  },
  {
    id: "gid://shopify/Product/9888889274660",
    handle: "เลื่อยยนต์-newwave-9800-super-pro-30-มีเอกสารพร้อมขึ้นทะเบียน",
    title: "เลื่อยยนต์ NEWWAVE 9800 SUPER PRO 30″ (มีทะเบียน)",
    price: 22000,
    image: `${CDN}/newwave-9800-super-pro-30-122116.webp?v=1750863138`,
    images: [
      `${CDN}/newwave-9800-super-pro-30-122116.webp?v=1750863138`,
      `${CDN}/newwave-9800-super-pro-30-738227.webp?v=1750863139`,
      `${CDN}/newwave-9800-super-pro-30-346988.webp?v=1750863140`,
      `${CDN}/newwave-9800-super-pro-30-376470.webp?v=1750863142`,
      `${CDN}/newwave-9800-super-pro-30-342990.webp?v=1750863143`,
    ],
    sold: 64,
    category: "chainsaw",
    description:
      "มีเอกสารพร้อมขึ้นทะเบียน (คำขอรับใบอนุญาต ลซ.1) • วิธีขอใบอนุญาตเลื่อยโซ่ยนต์: ดาวน์โหลดเอกสาร ลซ.1 • เตรียมสำเนาบัตรประชาชน + ทะเบียนบ้าน อย่างละ 4 ชุด และใบรับรองแพทย์ • ยื่นที่สำนักงานทรัพยากรธรรมชาติและสิ่งแวดล้อมจังหวัดของท่าน",
    variants: [{ title: '30"', price: 22000, stock: 0 }],
  },
  {
    id: "gid://shopify/Product/9887949390116",
    handle: "โซ่เลื่อยยนต์-ซอย-newwave-3623-3-8-ขนาดกลาง-titanium100-แบบเส้น",
    title: "โซ่เลื่อยยนต์ NEWWAVE 3623 (3/8) ขนาดกลาง Titanium100% (แบบซอย)",
    price: 360,
    compareAtPrice: 420,
    image: `${CDN}/newwave-3623-38-titanium100-721823.webp?v=1750862887`,
    images: [
      `${CDN}/newwave-3623-38-titanium100-721823.webp?v=1750862887`,
      `${CDN}/newwave-3623-38-titanium100-129472.webp?v=1750862888`,
      `${CDN}/newwave-3623-38-titanium100-125987.webp?v=1750862889`,
      `${CDN}/newwave-3623-38-titanium100-532858.webp?v=1750862891`,
      `${CDN}/newwave-3623-38-titanium100-717626.webp?v=1750862892`,
    ],
    sold: 5321,
    category: "chain",
    flashSale: true,
    variants: [
      { title: '11.5" 22T ซอย', price: 360, stock: 1026 },
      { title: '11.5" 22.5T ซอย', price: 370, stock: 1003 },
      { title: '12" 25T ซอย', price: 400, stock: 903 },
      { title: '12" 25.5T ซอย', price: 410, stock: 885 },
      { title: '16" 29T ซอย', price: 470, stock: 778 },
      { title: '16" 29.5T ซอย', price: 480, stock: 765 },
      { title: '16" 30T ซอย', price: 490, stock: 752 },
      { title: '16" 30.5T ซอย', price: 500, stock: 740 },
      { title: '16" 32T ซอย', price: 520, stock: 705 },
      { title: '18" 33T ซอย', price: 530, stock: 684 },
      { title: '18" 33.5T ซอย', price: 540, stock: 674 },
      { title: '18" 34T ซอย', price: 550, stock: 664 },
      { title: '20" 36T ซอย', price: 580, stock: 627 },
      { title: '20" 36.5T ซอย', price: 590, stock: 618 },
      { title: '22" 38T ซอย', price: 610, stock: 594 },
      { title: '22" 38.5T ซอย', price: 620, stock: 586 },
      { title: '25" 42T ซอย', price: 680, stock: 537 },
      { title: '25" 42.5T ซอย', price: 690, stock: 531 },
      { title: '28" 46T ซอย', price: 740, stock: 490 },
      { title: '30" 48T ซอย', price: 770, stock: 470 },
      { title: '30" 48.5T ซอย', price: 780, stock: 465 },
    ],
  },
  {
    id: "gid://shopify/Product/9885335683364",
    handle: "โซ่-kingkong-3-8-3623-ตัด-เกรด-a",
    title: "โซ่เลื่อยยนต์ KINGKONG 3623 (3/8) ขนาดกลาง เกรดA (แบบตัด)",
    price: 300,
    compareAtPrice: 350,
    image: `${CDN}/kingkong-3623-38-a-979608.webp?v=1750201002`,
    images: [
      `${CDN}/kingkong-3623-38-a-979608.webp?v=1750201002`,
      `${CDN}/kingkong-3623-38-a-693171.webp?v=1750201003`,
      `${CDN}/kingkong-3623-38-a-424963.webp?v=1750201031`,
      `${CDN}/kingkong-3623-38-a-540716.webp?v=1750201031`,
      `${CDN}/kingkong-3623-38-a-585447.webp?v=1750201061`,
    ],
    sold: 8214,
    category: "chain",
    flashSale: true,
    variants: [
      { title: '11.5" 21T ตัด', price: 300, stock: 1447 },
      { title: '11.5" 22T ตัด', price: 310, stock: 1381 },
      { title: '11.5" 22.5T ตัด', price: 320, stock: 1351 },
      { title: '12" 25T ตัด', price: 350, stock: 1216 },
      { title: '12" 25.5T ตัด', price: 360, stock: 1192 },
      { title: '16" 29T ตัด', price: 410, stock: 1048 },
      { title: '16" 29.5T ตัด', price: 420, stock: 1030 },
      { title: '16" 30T ตัด', price: 430, stock: 1013 },
      { title: '16" 30.5T ตัด', price: 440, stock: 996 },
      { title: '16" 32T ตัด', price: 450, stock: 950 },
      { title: '18" 33T ตัด', price: 470, stock: 921 },
      { title: '18" 33.5T ตัด', price: 480, stock: 907 },
      { title: '18" 34T ตัด', price: 490, stock: 894 },
      { title: '20" 36T ตัด', price: 510, stock: 844 },
      { title: '20" 36.5T ตัด', price: 520, stock: 832 },
      { title: '22" 38T ตัด', price: 540, stock: 800 },
      { title: '22" 38.5T ตัด', price: 550, stock: 789 },
      { title: '25" 42T ตัด', price: 590, stock: 723 },
      { title: '25" 42.5T ตัด', price: 600, stock: 715 },
      { title: '30" 48T ตัด', price: 680, stock: 633 },
      { title: '36" 57T ตัด', price: 800, stock: 533 },
      { title: '36" 57.5T ตัด', price: 810, stock: 528 },
      { title: '42" 68.5T ตัด', price: 960, stock: 443 },
      { title: '43" 69T ตัด', price: 970, stock: 440 },
    ],
  },
  {
    id: "gid://shopify/Product/9887588024612",
    handle: "โซ่-kingkong-1-4-สำหรับเลื่อยแบตเตอรี่",
    title: "โซ่เลื่อยยนต์ KINGKONG 1/4″ สำหรับเลื่อยแบตเตอรี่ไร้สายขนาดเล็ก",
    price: 120,
    image: `${CDN}/kingkong-14-629311.webp?v=1750202680`,
    images: [
      `${CDN}/kingkong-14-629311.webp?v=1750202680`,
      `${CDN}/kingkong-14-871966.webp?v=1750202707`,
      `${CDN}/kingkong-14-678943.webp?v=1750202707`,
      `${CDN}/kingkong-14-430596.webp?v=1750202736`,
      `${CDN}/kingkong-14-384317.webp?v=1750202736`,
    ],
    sold: 2109,
    category: "chain",
    variants: [
      { title: '4" 14T', price: 120, stock: 456 },
      { title: '6" 16.5T', price: 140, stock: 387 },
      { title: '6" 18T', price: 150, stock: 355 },
      { title: '6" 18.5T', price: 160, stock: 345 },
      { title: '8" 22T', price: 180, stock: 290 },
      { title: '8" 22.5T', price: 190, stock: 284 },
      { title: '8" 24T', price: 200, stock: 266 },
    ],
  },
];

// สินค้า Flash Sale
export const flashSaleProducts = products.filter((p) => p.flashSale);

// แปลงตัวเลขเป็นราคาไทย เช่น ฿4,500
export const formatPrice = (n: number) => `฿${n.toLocaleString("th-TH")}`;

// % ส่วนลด
export const discountPercent = (p: Product) =>
  p.compareAtPrice ? Math.round((1 - p.price / p.compareAtPrice) * 100) : 0;
