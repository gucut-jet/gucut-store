// Layer เชื่อม Shopify Storefront API (GraphQL)
// Phase 1: ยังไม่มี token → คืน mock data จาก products.ts
// Phase 2: ใส่ SHOPIFY_STOREFRONT_ACCESS_TOKEN ใน .env แล้วจะดึงข้อมูลสดอัตโนมัติ

import { products, type Product } from "./products";

const domain = process.env.SHOPIFY_STORE_DOMAIN;
const token = process.env.SHOPIFY_STOREFRONT_ACCESS_TOKEN;
const API_VERSION = "2025-04";

// มี credential ครบไหม
const hasShopify = Boolean(domain && token);

async function shopifyFetch<T>(query: string, variables: object = {}): Promise<T> {
  const res = await fetch(`https://${domain}/api/${API_VERSION}/graphql.json`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Shopify-Storefront-Access-Token": token!,
    },
    body: JSON.stringify({ query, variables }),
    next: { revalidate: 300 }, // cache 5 นาที
  });
  if (!res.ok) throw new Error(`Shopify API error: ${res.status}`);
  const json = await res.json();
  if (json.errors) throw new Error(JSON.stringify(json.errors));
  return json.data as T;
}

const PRODUCTS_QUERY = /* GraphQL */ `
  query Products($first: Int!) {
    products(first: $first) {
      edges {
        node {
          id
          handle
          title
          featuredImage { url }
          priceRange { minVariantPrice { amount } }
          compareAtPriceRange { minVariantPrice { amount } }
        }
      }
    }
  }
`;

// ดึงสินค้าทั้งหมด — สลับ mock/จริงตาม env อัตโนมัติ
export async function getProducts(): Promise<Product[]> {
  if (!hasShopify) return products; // ← mock

  type Resp = {
    products: {
      edges: {
        node: {
          id: string;
          handle: string;
          title: string;
          featuredImage: { url: string } | null;
          priceRange: { minVariantPrice: { amount: string } };
          compareAtPriceRange: { minVariantPrice: { amount: string } };
        };
      }[];
    };
  };
  const data = await shopifyFetch<Resp>(PRODUCTS_QUERY, { first: 50 });
  return data.products.edges.map(({ node }) => {
    const price = parseFloat(node.priceRange.minVariantPrice.amount);
    const compare = parseFloat(node.compareAtPriceRange.minVariantPrice.amount);
    return {
      id: node.id,
      handle: node.handle,
      title: node.title,
      price,
      compareAtPrice: compare > price ? compare : undefined,
      image: node.featuredImage?.url ?? "",
      images: node.featuredImage ? [node.featuredImage.url] : [],
      sold: 0,
      category: node.title.includes("โซ่") ? ("chain" as const) : ("chainsaw" as const),
    };
  });
}

export async function getProduct(handle: string): Promise<Product | undefined> {
  const all = await getProducts();
  return all.find((p) => p.handle === handle);
}
