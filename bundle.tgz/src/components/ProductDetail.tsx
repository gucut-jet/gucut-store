"use client";

import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { formatPrice, discountPercent, type Product } from "@/lib/products";
import { addToCart } from "@/lib/cart";

// หน้าสินค้าเต็ม: รูปสไลด์ / variant / วิดีโอ / สเปก / ปุ่มซื้อติดล่างจอ
export default function ProductDetail({ product }: { product: Product }) {
  const router = useRouter();
  const [img, setImg] = useState(0);
  const [showVideo, setShowVideo] = useState(false);
  const variants = product.variants ?? [{ title: "มาตรฐาน", price: product.price, stock: 99 }];
  const [vIdx, setVIdx] = useState(0);
  const [toast, setToast] = useState("");
  const v = variants[vIdx];
  const off = discountPercent(product);

  const add = () => {
    addToCart({
      productId: product.id,
      handle: product.handle,
      title: product.title,
      variant: v.title,
      price: v.price,
      image: product.image,
    });
    setToast("เพิ่มลงตะกร้าแล้ว ✓");
    setTimeout(() => setToast(""), 1600);
  };

  const buyNow = () => {
    add();
    router.push("/cart");
  };

  return (
    <main className="pb-36">
      {/* ปุ่มย้อนกลับลอยบนรูป */}
      <Link
        href="/"
        className="absolute left-3 top-3 z-30 flex h-9 w-9 items-center justify-center rounded-full bg-black/45 text-white backdrop-blur"
        aria-label="ย้อนกลับ"
      >
        ‹
      </Link>

      {/* รูปสไลด์ — ปัดดูได้ + จุดบอกตำแหน่ง */}
      <div className="relative">
        <div
          className="no-scrollbar flex snap-x snap-mandatory overflow-x-auto"
          onScroll={(e) => {
            const el = e.currentTarget;
            setImg(Math.round(el.scrollLeft / el.clientWidth));
          }}
        >
          {product.images.map((src, i) => (
            <div key={i} className="relative aspect-square w-full shrink-0 snap-center bg-white">
              <Image
                src={src}
                alt={`${product.title} รูปที่ ${i + 1}`}
                fill
                sizes="(max-width: 512px) 100vw, 512px"
                className="object-contain"
                priority={i === 0}
              />
            </div>
          ))}
        </div>
        <span className="absolute bottom-2 right-3 rounded-full bg-black/50 px-2 py-0.5 text-xs">
          {img + 1}/{product.images.length}
        </span>
      </div>

      {/* ราคา + ชื่อ */}
      <section className="px-4 pt-3">
        <div className="flex items-baseline gap-2">
          <span className="font-heading text-2xl font-bold text-safety">{formatPrice(v.price)}</span>
          {product.compareAtPrice && (
            <>
              <span className="text-sm text-steel-300 line-through">
                {formatPrice(product.compareAtPrice)}
              </span>
              <span className="rounded bg-safety/15 px-1.5 py-0.5 text-xs font-bold text-safety">
                -{off}%
              </span>
            </>
          )}
        </div>
        <h1 className="mt-1.5 font-heading text-lg font-semibold leading-snug">{product.title}</h1>
        <div className="mt-1 flex items-center gap-3 text-xs text-steel-300">
          <span>ขายแล้ว {product.sold.toLocaleString("th-TH")} ชิ้น</span>
          <span>·</span>
          <span>{v.stock > 0 ? `คงเหลือ ${v.stock.toLocaleString("th-TH")}` : "สินค้าหมดชั่วคราว — สั่งจองได้"}</span>
        </div>
      </section>

      {/* ปุ่มวิดีโอ YouTube */}
      <section className="mt-3 px-4">
        {product.youtubeId ? (
          <>
            <button
              onClick={() => setShowVideo((s) => !s)}
              className="flex w-full items-center justify-center gap-2 rounded-lg border border-red-600/60 bg-red-600/10 py-2.5 text-sm font-medium text-red-400"
            >
              ▶ {showVideo ? "ซ่อนวิดีโอ" : "ดูวิดีโอรีวิวสินค้านี้"}
            </button>
            {showVideo && (
              <div className="mt-2 aspect-video overflow-hidden rounded-lg">
                <iframe
                  className="h-full w-full"
                  src={`https://www.youtube.com/embed/${product.youtubeId}`}
                  title="วิดีโอรีวิว"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              </div>
            )}
          </>
        ) : (
          <a
            href="https://www.youtube.com/results?search_query=NEWWAVE+Legends"
            target="_blank"
            rel="noopener noreferrer"
            className="flex w-full items-center justify-center gap-2 rounded-lg border border-red-600/60 bg-red-600/10 py-2.5 text-sm font-medium text-red-400"
          >
            ▶ ชมรีวิวที่ช่อง NEWWAVE Legends
          </a>
        )}
      </section>

      {/* ตัวเลือกรุ่น/ขนาด */}
      {variants.length > 1 && (
        <section className="mt-4 px-4">
          <h2 className="font-heading text-sm font-semibold text-steel-300">
            เลือกรุ่น / ขนาด ({variants.length} ตัวเลือก)
          </h2>
          <div className="mt-2 flex flex-wrap gap-2">
            {variants.map((vt, i) => (
              <button
                key={vt.title}
                onClick={() => setVIdx(i)}
                className={`rounded-lg border px-3 py-1.5 text-sm transition-colors ${
                  i === vIdx
                    ? "border-safety bg-safety/15 font-semibold text-safety"
                    : "border-steel-700 bg-steel-800 text-gray-200"
                }`}
              >
                {vt.title} · {formatPrice(vt.price)}
              </button>
            ))}
          </div>
        </section>
      )}

      {/* สเปกตาราง */}
      <section className="mt-4 px-4">
        <h2 className="font-heading text-sm font-semibold text-steel-300">ข้อมูลสินค้า</h2>
        <table className="mt-2 w-full overflow-hidden rounded-lg text-sm">
          <tbody>
            {specRows(product).map(([k, val]) => (
              <tr key={k} className="border-b border-steel-900 bg-steel-800 last:border-0">
                <td className="w-1/3 px-3 py-2 text-steel-300">{k}</td>
                <td className="px-3 py-2">{val}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      {/* รายละเอียด */}
      {product.description && (
        <section className="mt-4 px-4">
          <h2 className="font-heading text-sm font-semibold text-steel-300">รายละเอียด</h2>
          <ul className="mt-2 space-y-1.5 text-sm leading-relaxed text-gray-200">
            {product.description.split("•").map(
              (part, i) =>
                part.trim() && (
                  <li key={i} className={i === 0 ? "font-medium" : "flex gap-2"}>
                    {i > 0 && <span className="text-safety">•</span>}
                    {part.trim()}
                  </li>
                )
            )}
          </ul>
        </section>
      )}

      {/* toast แจ้งเพิ่มตะกร้า */}
      {toast && (
        <div className="fixed inset-x-0 bottom-36 z-50 flex justify-center">
          <span className="rounded-full bg-black/80 px-4 py-2 text-sm text-white">{toast}</span>
        </div>
      )}

      {/* ปุ่มซื้อติดล่างจอ (อยู่เหนือ bottom nav) */}
      <div className="fixed inset-x-0 bottom-[57px] z-40 border-t border-steel-700 bg-steel-800/95 backdrop-blur">
        <div className="mx-auto flex max-w-lg gap-2 px-3 py-2.5">
          <button
            onClick={add}
            className="flex-1 rounded-lg border border-safety py-2.5 font-heading text-sm font-semibold text-safety active:scale-[0.98]"
          >
            เพิ่มลงตะกร้า
          </button>
          <button
            onClick={buyNow}
            className="flex-1 rounded-lg bg-safety py-2.5 font-heading text-sm font-bold text-white active:scale-[0.98]"
          >
            ซื้อเลย
          </button>
        </div>
      </div>
    </main>
  );
}

// แถวสเปกจากข้อมูลจริง (ไม่แต่งสเปกเครื่องเอง)
function specRows(p: Product): [string, string][] {
  const brand = /kingkong/i.test(p.title) ? "KingKong" : /newwave/i.test(p.title) ? "NEWWAVE" : "GUCUT";
  const rows: [string, string][] = [
    ["แบรนด์", brand],
    ["ประเภท", p.category === "chainsaw" ? "เลื่อยยนต์" : "โซ่เลื่อยยนต์"],
  ];
  if (p.title.includes("มีทะเบียน")) rows.push(["เอกสาร", "มีเอกสารพร้อมขึ้นทะเบียน (ลซ.1)"]);
  if (p.variants && p.variants.length > 1)
    rows.push(["ตัวเลือก", `${p.variants.length} ขนาด (${p.variants[0].title} – ${p.variants[p.variants.length - 1].title})`]);
  rows.push(["จัดส่ง", "ส่งไวทั่วไทย"]);
  return rows;
}
