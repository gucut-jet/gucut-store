// แถบค้นหาด้านบน — sticky แบบ Shopee
export default function SearchBar() {
  return (
    <header className="sticky top-0 z-40 bg-steel-900/95 px-3 py-2.5 backdrop-blur">
      <div className="flex items-center gap-2">
        <span className="font-heading text-xl font-bold text-safety">GUCUT</span>
        <div className="flex flex-1 items-center gap-2 rounded-full border border-steel-700 bg-steel-800 px-3.5 py-2">
          <svg className="h-4 w-4 shrink-0 text-steel-300" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
            <circle cx="11" cy="11" r="7" />
            <path strokeLinecap="round" d="m20 20-3.5-3.5" />
          </svg>
          <input
            type="search"
            placeholder="ค้นหาเลื่อยยนต์ โซ่ อะไหล่…"
            className="w-full bg-transparent text-sm text-gray-100 placeholder-steel-300 outline-none"
          />
        </div>
      </div>
    </header>
  );
}
