"use client";

import { useMemo, useState } from "react";
import { products, type Category } from "@/lib/products";
import ProductCard from "@/components/ProductCard";

// หน้าหมวดหมู่ + ตัวกรองราคา
const tabs: { key: Category | "all"; label: string }[] = [
  { key: "all", label: "ทั้งหมด" },
  { key: "chainsaw", label: "เลื่อยยนต์" },
  { key: "chain", label: "โซ่ / อะไหล่" },
  { key: "accessory", label: "อุปกรณ์เสริม" },
];

const priceRanges = [
  { label: "ทุกราคา", min: 0, max: Infinity },
  { label: "ต่ำกว่า ฿500", min: 0, max: 500 },
  { label: "฿500 – ฿5,000", min: 500, max: 5000 },
  { label: "฿5,000 – ฿15,000", min: 5000, max: 15000 },
  { label: "฿15,000 ขึ้นไป", min: 15000, max: Infinity },
];

export default function CategoryBrowser() {
  const [tab, setTab] = useState<Category | "all">("all");
  const [range, setRange] = useState(0);

  const filtered = useMemo(() => {
    const r = priceRanges[range];
    return products.filter(
      (p) => (tab === "all" || p.category === tab) && p.price >= r.min && p.price <= r.max
    );
  }, [tab, range]);

  return (
    <main>
      <header className="sticky top-0 z-40 bg-steel-900/95 backdrop-blur">
        <h1 className="px-4 pt-3 font-heading text-lg font-bold">หมวดหมู่สินค้า</h1>

        {/* แท็บหมวด */}
        <div className="no-scrollbar mt-2 flex gap-2 overflow-x-auto px-3 pb-2">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`shrink-0 rounded-full px-4 py-1.5 text-sm transition-colors ${
                tab === t.key
                  ? "bg-safety font-semibold text-white"
                  : "bg-steel-800 text-gray-200"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* ตัวกรองราคา */}
        <div className="no-scrollbar flex gap-2 overflow-x-auto border-b border-steel-800 px-3 pb-2.5">
          {priceRanges.map((r, i) => (
            <button
              key={r.label}
              onClick={() => setRange(i)}
              className={`shrink-0 rounded-md border px-2.5 py-1 text-xs transition-colors ${
                range === i
                  ? "border-safety bg-safety/15 font-semibold text-safety"
                  : "border-steel-700 text-steel-300"
              }`}
            >
              {r.label}
            </button>
          ))}
        </div>
      </header>

      {filtered.length === 0 ? (
        <p className="mt-16 text-center text-sm text-steel-300">
          ไม่มีสินค้าในเงื่อนไขนี้ ลองปรับตัวกรองดูครับ
        </p>
      ) : (
        <div className="mt-2 grid grid-cols-2 gap-2 px-3">
          {filtered.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
      <p className="px-4 py-3 text-center text-xs text-steel-600">{filtered.length} รายการ</p>
    </main>
  );
}
