import SearchBar from "@/components/SearchBar";
import BannerSlider from "@/components/BannerSlider";
import FlashSale from "@/components/FlashSale";
import ProductCard from "@/components/ProductCard";
import { getProducts } from "@/lib/shopify";

// หน้าแรก — feed สไตล์ Shopee
export default async function HomePage() {
  const products = await getProducts();

  return (
    <main>
      <SearchBar />
      <BannerSlider />
      <FlashSale />

      {/* grid สินค้า 2 คอลัมน์ */}
      <section className="mt-4 px-3">
        <h2 className="font-heading text-lg font-bold">
          สินค้าแนะนำ <span className="text-safety">🔥</span>
        </h2>
        <div className="mt-2 grid grid-cols-2 gap-2">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      <footer className="mt-8 px-3 pb-4 text-center text-xs text-steel-600">
        GUCUT — เลื่อยยนต์ NEWWAVE / KingKong ของแท้ · gucut.com
      </footer>
    </main>
  );
}
