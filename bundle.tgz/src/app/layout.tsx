import type { Metadata, Viewport } from "next";
import "./globals.css";
import BottomNav from "@/components/BottomNav";

export const metadata: Metadata = {
  title: "GUCUT — เลื่อยยนต์ NEWWAVE / KingKong ของแท้",
  description:
    "ร้าน GUCUT ขายเลื่อยยนต์ NEWWAVE และ KingKong ของแท้ พร้อมโซ่ อะไหล่ อุปกรณ์เสริม ส่งไวทั่วไทย",
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, title: "GUCUT", statusBarStyle: "black-translucent" },
};

export const viewport: Viewport = {
  themeColor: "#1a1d21",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="th">
      <head>
        {/* ฟอนต์ Kanit (หัวข้อ) + IBM Plex Sans Thai (เนื้อหา) */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Kanit:wght@500;600;700&family=IBM+Plex+Sans+Thai:wght@400;500;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="font-body">
        {/* เผื่อพื้นที่ล่างให้ bottom nav */}
        <div className="mx-auto min-h-screen max-w-lg pb-20">{children}</div>
        <BottomNav />
      </body>
    </html>
  );
}
