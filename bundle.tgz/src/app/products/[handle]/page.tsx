import { getProduct } from "@/lib/shopify";
import { products } from "@/lib/products";
import ProductDetail from "@/components/ProductDetail";

// สร้างหน้า static ล่วงหน้าทุกสินค้า (จำเป็นสำหรับ output: "export")
export function generateStaticParams() {
  return products.map((p) => ({ handle: p.handle }));
}

// หน้าสินค้า — server component ดึงข้อมูล แล้วส่งให้ ProductDetail (client)
export default async function ProductPage({
  params,
}: {
  params: Promise<{ handle: string }>;
}) {
  const { handle } = await params;
  const product = await getProduct(decodeURIComponent(handle));

  if (!product) {
    return <main className="p-6 text-center text-steel-300">ไม่พบสินค้า</main>;
  }

  return <ProductDetail product={product} />;
}
