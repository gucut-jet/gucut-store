import CategoryBrowser from "@/components/CategoryBrowser";

export default function CategoriesPage() {
  return <CategoryBrowser />;
}
