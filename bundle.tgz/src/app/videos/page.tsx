import VideoFeed from "@/components/VideoFeed";

export default function VideosPage() {
  return <VideoFeed />;
}
