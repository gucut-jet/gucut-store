import type { Config } from "tailwindcss";

// ธีม "industrial steel + safety orange" ของ GUCUT
const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        steel: {
          900: "#1a1d21", // พื้นหลังหลัก
          800: "#2a2e33", // พื้นการ์ด/แถบ
          700: "#3a3f46",
          600: "#4d545c",
          300: "#9aa3ad",
        },
        safety: {
          DEFAULT: "#ff6b00", // ส้ม safety สีหลัก
          dark: "#e05e00",
          light: "#ff8a33",
        },
      },
      fontFamily: {
        heading: ["Kanit", "sans-serif"],
        body: ["'IBM Plex Sans Thai'", "sans-serif"],
      },
    },
  },
  plugins: [],
};
export default config;
